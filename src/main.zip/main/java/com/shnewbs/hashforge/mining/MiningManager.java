package com.shnewbs.hashforge.mining;

import com.shnewbs.hashforge.blocks.ASICMinerBlockEntity;
import com.shnewbs.hashforge.HashForgeMod;
import com.shnewbs.hashforge.currency.CurrencyType;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class MiningManager {
    private static final Logger LOGGER = LogManager.getLogger();
    private final Map<String, List<BlockPos>> playerMiners = new ConcurrentHashMap<>();
    private final Map<String, CurrencyType> playerActiveCoins = new ConcurrentHashMap<>();
    private final Map<BlockPos, Double> minerHeatLevels = new ConcurrentHashMap<>();
    private static ServerLevel serverLevel;

    // Constants for mining calculations
    private static final double BASE_MINING_RATE = 0.00000001;
    private static final double MAX_EFFICIENCY = 1.25;
    private static final double HEAT_THRESHOLD = 100.0;
    private static final int HEAT_RADIUS = 3;

    public void setServerLevel(ServerLevel level) {
        serverLevel = level;
    }

    public void registerMiner(String playerUUID, BlockPos minerPos) {
        playerMiners.computeIfAbsent(playerUUID, k -> new ArrayList<>()).add(minerPos);
        minerHeatLevels.put(minerPos, 0.0);
        LOGGER.info("Registered new miner for player {} at position {}", playerUUID, minerPos);
    }

    public void unregisterMiner(String playerUUID, BlockPos minerPos) {
        List<BlockPos> miners = playerMiners.get(playerUUID);
        if (miners != null) {
            miners.remove(minerPos);
            minerHeatLevels.remove(minerPos);
            if (miners.isEmpty()) {
                playerMiners.remove(playerUUID);
            }
            LOGGER.info("Unregistered miner for player {} at position {}", playerUUID, minerPos);
        }
    }

    private double calculateMinerEfficiency(ASICMinerBlockEntity miner) {
        double baseEfficiency = miner.getHashRate() / 1000000.0; // Convert to MH/s
        return Math.min(baseEfficiency, MAX_EFFICIENCY);
    }

    private double calculateMiningReward(CurrencyType coin, double hashRate) {
        double baseReward = BASE_MINING_RATE * hashRate;
        double circulationFactor = 1.0 - (coin.getCirculationPercentage() / 100.0);
        return baseReward * circulationFactor;
    }

    private double calculateHeatFactor(BlockPos minerPos) {
        List<BlockPos> nearbyMiners = minerHeatLevels.keySet().stream()
                .filter(pos -> pos.closerThan(minerPos, HEAT_RADIUS))
                .collect(Collectors.toList());

        double totalHeat = nearbyMiners.stream()
                .mapToDouble(pos -> minerHeatLevels.getOrDefault(pos, 0.0))
                .sum();

        return 1.0 + (totalHeat / HEAT_THRESHOLD);
    }

    public void processMining(String playerUUID, ASICMinerBlockEntity miner, CurrencyType coin) {
        if (coin == null) return;

        try {
            double efficiency = calculateMinerEfficiency(miner);
            double hashRate = miner.getHashRate() * efficiency;
            double heatFactor = calculateHeatFactor(miner.getBlockPos());
            double difficulty = coin.getDifficulty();

            double miningChance = (hashRate / difficulty) * (1.0 / heatFactor);
            if (Math.random() < miningChance && coin.addToSupply(1)) {
                double reward = calculateMiningReward(coin, hashRate);
                String txId = String.format("MINE_%s_%s_%d",
                        coin.getName(),
                        playerUUID.substring(0, 8),
                        System.currentTimeMillis());

                HashForgeMod.walletManager.creditMiningReward(playerUUID, coin, reward, txId);

                LOGGER.info("Player {} mined {} {} (TX: {})",
                        playerUUID, reward, coin.getName(), txId);
            }

            updateMinerHeat(miner.getBlockPos());
            updateEnvironmentalEffects(miner.getBlockPos());

        } catch (Exception e) {
            LOGGER.error("Error processing mining for player {}: {}", playerUUID, e.getMessage());
        }
    }

    private void updateMinerHeat(BlockPos minerPos) {
        double currentHeat = minerHeatLevels.getOrDefault(minerPos, 0.0);
        double newHeat = Math.min(currentHeat + 0.1, HEAT_THRESHOLD * 2);
        minerHeatLevels.put(minerPos, newHeat);
    }

    private void updateEnvironmentalEffects(BlockPos pos) {
        if (serverLevel == null) return;

        double heat = minerHeatLevels.getOrDefault(pos, 0.0);
        if (heat > HEAT_THRESHOLD) {
            BlockPos.betweenClosed(
                    pos.offset(-HEAT_RADIUS, -HEAT_RADIUS, -HEAT_RADIUS),
                    pos.offset(HEAT_RADIUS, HEAT_RADIUS, HEAT_RADIUS)
            ).forEach(blockPos -> {
                Block block = serverLevel.getBlockState(blockPos).getBlock();
                if (block == net.minecraft.world.level.block.Blocks.SNOW ||
                        block == net.minecraft.world.level.block.Blocks.ICE) {
                    serverLevel.removeBlock(blockPos, false);
                }
            });
        }
    }

    public void setPlayerActiveCoin(String playerUUID, CurrencyType coin) {
        playerActiveCoins.put(playerUUID, coin);
        LOGGER.info("Player {} switched to mining {}", playerUUID, coin.getName());
    }

    public CurrencyType getPlayerActiveCoin(String playerUUID) {
        return playerActiveCoins.get(playerUUID);
    }

    public void cooldownMiners() {
        minerHeatLevels.replaceAll((pos, heat) -> Math.max(0, heat - 0.05));
    }
}
