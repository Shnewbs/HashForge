package com.shnewbs.hashforge.wallet;

import com.shnewbs.hashforge.currency.CurrencyType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

public class WalletManager {
    private static final Logger LOGGER = LogManager.getLogger();
    private final Map<String, Wallet> playerWallets = new HashMap<>();

    public boolean hasWallet(String playerUUID) {
        return playerWallets.containsKey(playerUUID);
    }

    public Wallet getWallet(String playerUUID) {
        return playerWallets.get(playerUUID);
    }

    public void createWallet(String playerUUID) {
        if (!hasWallet(playerUUID)) {
            Wallet newWallet = new Wallet();
            playerWallets.put(playerUUID, newWallet);
            LOGGER.info("Created new wallet for player: " + playerUUID);
        }
    }

    public double getBalance(String playerUUID, CurrencyType currencyType) {
        Wallet wallet = playerWallets.get(playerUUID);
        if (wallet != null) {
            return wallet.getBalance(currencyType);
        }
        return 0.0;
    }

    public boolean transfer(String fromPlayerUUID, String toPlayerUUID, CurrencyType currencyType, double amount) {
        if (amount <= 0) {
            LOGGER.warn("Transfer failed: Invalid amount " + amount);
            return false;
        }

        Wallet fromWallet = playerWallets.get(fromPlayerUUID);
        Wallet toWallet = playerWallets.get(toPlayerUUID);

        if (fromWallet == null || toWallet == null) {
            LOGGER.warn("Transfer failed: Invalid wallet(s)");
            return false;
        }

        // Check if sender has enough balance
        if (fromWallet.getBalance(currencyType) < amount) {
            LOGGER.warn("Transfer failed: Insufficient funds");
            return false;
        }

        // Perform the transfer
        if (fromWallet.subtractBalance(currencyType, amount)) {
            toWallet.addBalance(currencyType, amount);
            LOGGER.info(String.format("Transferred %.8f %s from %s to %s",
                    amount, currencyType, fromPlayerUUID, toPlayerUUID));
            return true;
        }

        return false;
    }

    public void creditMiningReward(String playerUUID, CurrencyType currencyType, double amount, String transactionId) {
        Wallet wallet = playerWallets.get(playerUUID);
        if (wallet != null) {
            // Add as pending reward first
            wallet.addPendingReward(currencyType, amount, transactionId);
            LOGGER.info(String.format("Added pending mining reward of %.8f %s for player %s",
                    amount, currencyType, playerUUID));
        } else {
            LOGGER.warn(String.format("Failed to credit mining reward: Wallet not found for player %s", playerUUID));
        }
    }

    public void processPendingRewards(String playerUUID) {
        Wallet wallet = playerWallets.get(playerUUID);
        if (wallet != null) {
            List<PendingReward> pendingRewards = wallet.getPendingRewards();

            for (PendingReward reward : pendingRewards) {
                wallet.addBalance(reward.getCurrencyType(), reward.getAmount());
                LOGGER.info(String.format("Processed pending reward of %.8f %s for player %s",
                        reward.getAmount(), reward.getCurrencyType(), playerUUID));
            }

            wallet.clearPendingRewards();
        } else {
            LOGGER.warn(String.format("Failed to process pending rewards: Wallet not found for player %s", playerUUID));
        }
    }

    public List<PendingReward> getPendingRewards(String playerUUID) {
        Wallet wallet = playerWallets.get(playerUUID);
        if (wallet != null) {
            return wallet.getPendingRewards();
        }
        LOGGER.warn(String.format("Failed to get pending rewards: Wallet not found for player %s", playerUUID));
        return List.of(); // Return empty list if no wallet exists
    }

    public void saveWallets() {
        // TODO: Implement saving wallet data to a file
        // This should save all wallet data including:
        // - Balances for each currency type
        // - Pending rewards
        // - Player UUIDs
        LOGGER.info("Saving wallet data...");
    }

    public void loadWallets() {
        // TODO: Implement loading wallet data from a file
        // This should load and reconstruct:
        // - Wallet objects
        // - Balance mappings
        // - Pending rewards
        LOGGER.info("Loading wallet data...");
    }
}