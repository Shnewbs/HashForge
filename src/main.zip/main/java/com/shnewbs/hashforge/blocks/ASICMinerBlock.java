package com.shnewbs.hashforge.blocks;

import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import com.mojang.serialization.MapCodec;
import com.shnewbs.hashforge.blocks.ASICMinerBlockEntity;

public class ASICMinerBlock extends BaseEntityBlock {

    public static final MapCodec<ASICMinerBlock> CODEC = simpleCodec(ASICMinerBlock::new);

    public ASICMinerBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ASICMinerBlockEntity(pos, state); // Updated constructor to only include pos and state
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    // Additional methods can be added here as needed
}
