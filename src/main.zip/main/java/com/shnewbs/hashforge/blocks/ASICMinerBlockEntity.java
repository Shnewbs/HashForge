package com.shnewbs.hashforge.blocks;

import com.shnewbs.hashforge.HashForgeMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class ASICMinerBlockEntity extends BlockEntity {
    private double hashRate = 0;
    private double efficiency = 1.0;
    private int energy = 0;
    private static final int MAX_ENERGY = 50000;
    private static final double BASE_HASH_RATE = 1.0;

    public ASICMinerBlockEntity(BlockPos pos, BlockState state) {
        super(HashForgeMod.ASIC_MINER_BLOCK_ENTITY.get(), pos, state);
    }

    public double getHashRate() {
        return hashRate;
    }

    public double getEfficiency() {
        return efficiency;
    }

    public void tick() {
        if (level != null && !level.isClientSide) {
            if (energy > 0) {
                // Convert energy to hash rate
                hashRate = (energy / (double)MAX_ENERGY) * BASE_HASH_RATE;
                energy--;
            } else {
                hashRate = 0;
            }
        }
    }

    public void addEnergy(int amount) {
        energy = Math.min(energy + amount, MAX_ENERGY);
    }

    public int getEnergy() {
        return energy;
    }

    public int getMaxEnergy() {
        return MAX_ENERGY;
    }
}