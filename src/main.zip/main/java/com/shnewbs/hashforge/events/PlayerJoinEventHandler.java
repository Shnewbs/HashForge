package com.shnewbs.hashforge.events;

import com.shnewbs.hashforge.currency.CurrencyType;
import com.shnewbs.hashforge.HashForgeMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PlayerJoinEventHandler {
    private static final Logger LOGGER = LogManager.getLogger();

    public static void init() {
        // Register this class to the NeoForge event bus
        NeoForge.EVENT_BUS.register(PlayerJoinEventHandler.class);
    }

    @SubscribeEvent
    public static void onPlayerJoin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            String playerUUID = player.getStringUUID();
            LOGGER.info("Player joined with UUID: " + playerUUID);

            // Check if player has a wallet
            if (!HashForgeMod.walletManager.hasWallet(playerUUID)) {
                // Create new wallet
                HashForgeMod.walletManager.createWallet(playerUUID);

                // Notify player
                player.sendSystemMessage(Component.literal("Welcome! A new wallet has been created for you."));
                player.sendSystemMessage(Component.literal("Use /wallet balance to check your balance."));

                LOGGER.info("Created new wallet for player: " + playerUUID);
            } else {
                // Welcome back message with wallet info
                StringBuilder balanceMsg = new StringBuilder("Welcome back! Your wallet balances:\n");

                for (CurrencyType currency : CurrencyType.values()) {
                    double balance = HashForgeMod.walletManager.getBalance(playerUUID, currency);
                    balanceMsg.append(String.format("%s: %.8f\n", currency.name(), balance));
                }

                player.sendSystemMessage(Component.literal(balanceMsg.toString()));
                LOGGER.info("Player returned with existing wallet: " + playerUUID);
            }
        }
    }
}