package com.shnewbs.hashforge.items;

import com.shnewbs.hashforge.currency.CurrencyType;
import com.shnewbs.hashforge.HashForgeMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

public class CoinCreatorItem extends Item {

    public CoinCreatorItem(Properties properties) {
        super(properties);
    }

    public void onUse(ItemStack stack, ServerPlayer player) {
        CompoundTag tag = stack.getOrCreateTag();  // Correct method for tags

        if (tag != null) {
            String coinName = tag.getString("coinName");
            String symbol = tag.getString("symbol");
            long maxSupply = tag.getLong("maxSupply");

            CurrencyType newCoin = HashForgeMod.getInstance().getCoinRegistry().registerCoin(coinName, symbol, maxSupply);
            player.sendSystemMessage(Component.literal("Successfully created currency: " + newCoin.getName()));
        }
    }
}
