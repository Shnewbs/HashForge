package com.shnewbs.hashforge.currency;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class CoinRegistry {

    // Map to store dynamically registered coins (using CurrencyType)
    private final Map<String, CurrencyType> dynamicCoins = new HashMap<>();

    // Registers a new dynamic coin
    public CurrencyType registerCoin(String name, String symbol, long maxSupply) {
        if (dynamicCoins.containsKey(name.toUpperCase())) {
            throw new IllegalArgumentException("Coin with name '" + name + "' already exists.");
        }

        // Register the new coin in CurrencyType
        CurrencyType newCoin = CurrencyType.registerCoin(name, symbol, maxSupply);
        dynamicCoins.put(name.toUpperCase(), newCoin);
        return newCoin;
    }

    // Retrieves a dynamic coin by name
    public Optional<CurrencyType> getCurrencyType(String name) {
        return Optional.ofNullable(dynamicCoins.get(name.toUpperCase()));
    }

    // Loads coins (stub for now)
    public void loadCoins() {
        // Placeholder for loading logic (e.g., from a file or database)
    }

    // Retrieves all coins (both predefined and dynamic)
    public Map<String, CurrencyType> getAllCoins() {
        return CurrencyType.getAllCoins();  // Get all coins from CurrencyType
    }
}
