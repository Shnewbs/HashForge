package com.shnewbs.hashforge;

public enum CurrencyType {
    HASHCOIN, // Add other coin types as needed
    // You can add other currency types here
}
