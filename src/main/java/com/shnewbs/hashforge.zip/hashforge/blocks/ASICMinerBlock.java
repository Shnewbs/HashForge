package com.shnewbs.hashforge.blocks;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;

public class ASICMinerBlock extends Block {

    public ASICMinerBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    // Additional custom logic for ASICMinerBlock can be added here
}
