package com.shnewbs.hashforge.blocks;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import com.shnewbs.hashforge.HashForgeMod;

import javax.annotation.Nullable;
import java.util.UUID;

public class ASICMinerBlockEntity extends BlockEntity {
    private int energyStored;
    private int maxEnergyStored;
    private UUID ownerUUID;
    private String currentCoin;
    private double hashRate;
    private double efficiency;
    private double heatOutput;
    private boolean isPowered;
    private int energyConsumption;

    public ASICMinerBlockEntity(BlockPos pos, BlockState state) {
        super(HashForgeMod.ASIC_MINER_BLOCK_ENTITY.get(), pos, state);
        this.maxEnergyStored = 100000; // Example maximum energy value
        this.energyStored = 0; // Initially, no energy is stored
        this.currentCoin = "";
        this.hashRate = 0;
        this.efficiency = 100;
        this.heatOutput = 0;
        this.isPowered = false;
        this.energyConsumption = 0;
    }

    // Getter methods
    public String getCurrentCoin() {
        return currentCoin;
    }

    public double getHashRate() {
        return hashRate;
    }

    public boolean isPowered() {
        return isPowered;
    }

    public int getEnergyConsumption() {
        return energyConsumption;
    }

    public double getEfficiency() {
        return efficiency;
    }

    public double getHeatOutput() {
        return heatOutput;
    }

    // Setter methods
    public void setCurrentCoin(String coin) {
        this.currentCoin = coin;
        setChanged();
    }

    public void setHashRate(double hashRate) {
        this.hashRate = hashRate;
        setChanged();
    }

    public void setPowered(boolean powered) {
        this.isPowered = powered;
        setChanged();
    }

    public void setEnergyConsumption(int consumption) {
        this.energyConsumption = consumption;
        setChanged();
    }

    public void setEfficiency(double efficiency) {
        this.efficiency = efficiency;
        setChanged();
    }

    public void setHeatOutput(double heatOutput) {
        this.heatOutput = heatOutput;
        setChanged();
    }

    // Tick method: to perform the mining logic
    public void tick() {
        if (level.isClientSide()) return;

        isPowered = energyStored > 0;
        if (isPowered) {
            energyStored -= energyConsumption; // Reduce energy based on consumption
            if (energyStored < 0) energyStored = 0; // Prevent negative energy

            performMining();
            setChanged(); // Mark the block as changed so it will be saved
        }
    }

    private void performMining() {
        // Implement your custom mining logic here
        // Example: increase the hashRate, generate some currency, etc.
        // Also adjust heatOutput and efficiency accordingly
    }

    // Saving data to NBT for persistence
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("EnergyStored", energyStored);
        tag.putInt("MaxEnergyStored", maxEnergyStored);
        tag.putString("CurrentCoin", currentCoin);
        tag.putDouble("HashRate", hashRate);
        tag.putDouble("Efficiency", efficiency);
        tag.putDouble("HeatOutput", heatOutput);
        tag.putBoolean("IsPowered", isPowered);
        tag.putInt("EnergyConsumption", energyConsumption);
    }

    // Loading data from NBT
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        energyStored = tag.getInt("EnergyStored");
        maxEnergyStored = tag.getInt("MaxEnergyStored");
        currentCoin = tag.getString("CurrentCoin");
        hashRate = tag.getDouble("HashRate");
        efficiency = tag.getDouble("Efficiency");
        heatOutput = tag.getDouble("HeatOutput");
        isPowered = tag.getBoolean("IsPowered");
        energyConsumption = tag.getInt("EnergyConsumption");
    }

    // Networking sync
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return new ClientboundBlockEntityDataPacket(worldPosition, 1, tag);
    }

    @Override
    public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt) {
        load(pkt.getTag());
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public void handleUpdateTag(CompoundTag tag) {
        load(tag);
    }

    // Call this on block removal to avoid memory leaks
    @Override
    public void setRemoved() {
        super.setRemoved();
    }
}
