package com.shnewbs.hashforge;

import com.mojang.brigadier.CommandDispatcher;
import com.shnewbs.hashforge.commands.WalletCommands;
import net.minecraft.commands.CommandSourceStack;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.neoforged.fml.common.Mod;  // Make sure this is the correct Mod annotation for NeoForge

@Mod(HashForgeMod.MOD_ID)
public class HashForgeMod {
    public static final String MOD_ID = "hashforge";
    private static final Logger LOGGER = LogManager.getLogger();

    public HashForgeMod() {
        // Mod constructor logic, if any
    }

    @SubscribeEvent
    public static void onServerStarting(ServerStartingEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getServer().getCommands().getDispatcher();
        WalletCommands.registerCommands(dispatcher);
        LOGGER.info("Commands registered successfully!");
    }
}
