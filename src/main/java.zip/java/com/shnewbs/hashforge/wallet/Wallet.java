package com.shnewbs.hashforge.wallet;

import java.util.UUID;

public class Wallet {
    private UUID playerUUID;
    private double balance;

    public Wallet(UUID playerUUID) {
        this.playerUUID = playerUUID;
        this.balance = 0.0;
    }

    public double getBalance() {
        return balance;
    }

    public void addBalance(double amount) {
        this.balance += amount;
    }

    public void subtractBalance(double amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
        } else {
            throw new IllegalArgumentException("Insufficient balance");
        }
    }

    public String getHashString() {
        return playerUUID.toString(); // Example hash string, replace with actual hash logic if needed
    }
}
