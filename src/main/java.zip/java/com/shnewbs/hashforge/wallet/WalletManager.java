package com.shnewbs.hashforge.wallet;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class WalletManager {
    private final Map<UUID, Wallet> wallets = new HashMap<>();

    // Create a new wallet when a player joins the server
    public Wallet createWallet(UUID playerUUID) {
        Wallet wallet = new Wallet(playerUUID);
        wallets.put(playerUUID, wallet);
        return wallet;
    }

    // Get a player's wallet
    public Wallet getWallet(UUID playerUUID) {
        return wallets.get(playerUUID);
    }

    // Save wallets to file or database here in the future for persistence
}
