package com.shnewbs.hashforge;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.shnewbs.hashforge.wallet.Wallet;
import com.shnewbs.hashforge.wallet.WalletManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModLoadingContext;
import com.shnewbs.hashforge.events.PlayerJoinEventHandler;
import net.neoforged.neoforge.common.NeoForge;

@Mod("hashforge")
public class HashForgeMod {
    public static WalletManager walletManager = new WalletManager(); // Initialize walletManager here

    public HashForgeMod() {
        IEventBus modEventBus = ModLoadingContext.get().getEventBus(); // Attempting to use a different method for event bus retrieval
        modEventBus.addListener(this::setup);

        // Register event handlers
        registerEventHandlers();
    }

    private void setup(final FMLCommonSetupEvent event) {
        // Initialization code
    }

    private void registerEventHandlers() {
        // Register your event handlers here
        NeoForge.EVENT_BUS.register(new PlayerJoinEventHandler()); // Register using NeoForge event bus
    }

    public static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("balance")
                .executes(HashForgeMod::showBalance));
        dispatcher.register(Commands.literal("wallethash")
                .executes(HashForgeMod::showWalletHash));
    }

    private static int showBalance(CommandContext<CommandSourceStack> context) {
        ServerPlayer player = context.getSource().getPlayerOrException();
        Wallet wallet = walletManager.getWallet(player.getUUID());
        if (wallet != null) {
            player.sendSystemMessage(Component.literal("Your balance is: " + wallet.getBalance()));
        } else {
            player.sendSystemMessage(Component.literal("No wallet found."));
        }
        return 1;
    }

    private static int showWalletHash(CommandContext<CommandSourceStack> context) {
        ServerPlayer player = context.getSource().getPlayerOrException();
        Wallet wallet = walletManager.getWallet(player.getUUID());
        if (wallet != null) {
            player.sendSystemMessage(Component.literal("Your wallet hash: " + wallet.getHashString()));
        } else {
            player.sendSystemMessage(Component.literal("No wallet found."));
        }
        return 1;
    }
}
