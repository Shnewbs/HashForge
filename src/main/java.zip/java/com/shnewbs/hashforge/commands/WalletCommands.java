package com.shnewbs.hashforge.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.shnewbs.hashforge.wallet.WalletManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class WalletCommands {
    private static final WalletManager walletManager = new WalletManager();

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("balance")
                .executes(context -> {
                    ServerPlayer player = context.getSource().getPlayerOrException();
                    double balance = walletManager.getWallet(player.getUUID()).getBalance();
                    player.sendSystemMessage(Component.literal("Your balance is: " + balance));
                    return 1;
                })
        );
    }
}
